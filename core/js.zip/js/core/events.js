define(function(){
    //Map events-----------------------------
    amplify.subscribe( 'mapBeforeLoad', function(){
       
    });
    amplify.subscribe( 'mapBeforeLoad', function(){
       
    });
    amplify.subscribe( 'mapAfterLoad', function(){
        
    });
    amplify.subscribe( 'mapReload', function(){
        
    });
    //mapFeatures------------------------------------------
    amplify.subscribe( 'mapFeatureAdded', function(data){
    });
   return 
});