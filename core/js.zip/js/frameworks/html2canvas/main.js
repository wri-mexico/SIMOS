module.exports = require('./dist/html2canvas').html2canvas;
